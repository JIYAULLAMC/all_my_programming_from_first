import React from "react";

function InputSubmit(props) {
  return (
    <div>
      <input type="submit" value={props.name} />
    </div>
  );
}

export default InputSubmit;
