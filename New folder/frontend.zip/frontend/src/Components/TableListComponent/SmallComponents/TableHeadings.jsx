import React from 'react'

function TableHeadings(props) {
  return (
    <th>{props.value}</th>
  )
}

export default TableHeadings