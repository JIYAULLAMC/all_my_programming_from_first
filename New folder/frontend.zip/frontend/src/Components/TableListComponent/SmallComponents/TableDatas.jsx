import React from "react";

function TableDatas(props) {
  return <td>{props.value}</td>;
}

export default TableDatas;
